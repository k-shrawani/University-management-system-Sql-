use university;
select*from students;
select*from professors;
select*from departments;
select*from courses;
select*from classes;
select * from enrollment;


-- Add a new course to the course table
INSERT INTO Courses (course_name, department_id) 
VALUES ('Artificial Intelligence',11);

-- Change the name of student
SET SQL_SAFE_UPDATES = 0; 
UPDATE Students 
SET student_name = 'Anjali .M.Gupta' 
WHERE student_name = 'Anjali Gupta';

-- Check the Structure of the Students Table
DESCRIBE students;

--  Update a Student's Email Address
UPDATE Students 
SET email = 'rahul.singh@newemail.com' 
WHERE student_name = 'Rahul Singh';

-- Rename a email Column in the Professors Table 
ALTER TABLE Professors RENAME COLUMN email TO email_address;

-- Add new column to the students Table
ALTER TABLE students Add column phone_number VARCHAR(15);

