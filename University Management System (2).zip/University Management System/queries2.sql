use university;
select*from students;
select*from professors;
select*from departments;
select*from courses;
select*from classes;
select * from enrollment;

-- Count the number of students in each course
SELECT co.course_name, COUNT(e.student_id) AS student_count
FROM Courses co
LEFT JOIN Classes c ON co.course_id = c.course_id
LEFT JOIN Enrollment e ON c.class_id = e.class_id
GROUP BY co.course_name;

 -- Find all courses taught by professors with a specific email domain ('@university.in')
 SELECT DISTINCT c.course_name
FROM Courses c
JOIN Classes cl ON c.course_id = cl.course_id
JOIN Professors p ON cl.professor_id = p.professor_id
WHERE p.email LIKE '%@university.in';

-- List all students along with their courses and grades
SELECT s.student_name, c.course_name, e.grade
FROM Students s
JOIN Enrollment e ON s.student_id = e.student_id
JOIN Classes cl ON e.class_id = cl.class_id
JOIN Courses c ON cl.course_id = c.course_id;

-- Find the total number of courses in each department
SELECT d.department_name, COUNT(course_id) AS course_count
FROM Departments d
LEFT JOIN Courses c ON d.department_id = c.department_id
GROUP BY d.department_name;

--  Find All Classes in a Specific Semester
SELECT c.course_name, p.professor_name 
FROM Classes cl
JOIN Courses c ON cl.course_id = c.course_id
JOIN Professors p ON cl.professor_id = p.professor_id
WHERE cl.semester = 'Fall 2023';

--  Get All Enrollments for a Specific Student (e.g., 'Rahul Singh')
SELECT c.course_name, e.grade 
FROM Enrollment e
JOIN Classes cl ON e.class_id = cl.class_id
JOIN Courses c ON cl.course_id = c.course_id
JOIN Students s ON e.student_id = s.student_id
WHERE s.student_name = 'Rahul Singh';

-- List All Professors with Their Departments
SELECT p.professor_name, d.department_name 
FROM Professors p
JOIN Departments d ON p.department_id = d.department_id;

