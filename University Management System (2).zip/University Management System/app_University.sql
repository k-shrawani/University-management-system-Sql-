-- University Management System
-- University Management Sql
-- Create Database University

Create database University; 
-- Create Table Departments
Drop table if exists Departments;
Create table Departments (
department_id INT Auto_Increment primary key,
department_name VARCHAR (100) NOT NULL
);
-- Create table Professors
Drop table if exists Peofessors;
create table Professors (
professor_id INT Auto_Increment Primary key,
professor_name VARCHAR (100) NOT NULL,
email VARCHAR (100),
department_id INT
);
-- Create table Students 
Drop table if exists students;
create table Students (
student_id INT AUTO_INCREMENT PRIMARY KEY,
student_name VARCHAR (100) NOT NULL,
email VARCHAR (100),
enrollment_date DATE 
);
-- Create Table Courses 
Drop table If exists courses;
create table courses (
course_id INT Auto_Increment PRIMARY KEY,
Course_name VARCHAR (100) NOT NULL,
deparment_id INT 
);
-- create table classes
Drop table If exists classes;
create table Classes (
class_id INT AUTO_INCREMENT PRIMARY KEY,
course_id INT, 
professor_id INT,
semester VARCHAR (20)
);
-- Create table enrollment
Drop table If exists Enrollment;
create table Enrollment (
enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
student_id INT,
class_id INT,
enrollment_date DATE,
grade CHAR (2)
);