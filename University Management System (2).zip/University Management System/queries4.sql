use university;
select*from students;
select*from professors;
select*from departments;
select*from courses;
select*from classes;
select * from enrollment;

-- Count the Total Number of Enrollments
SELECT COUNT(*) AS total_enrollments 
FROM Enrollment;

-- Get Total Enrollment per Professor
SELECT p.professor_name, COUNT(e.enrollment_id) AS total_enrollments
FROM Professors p
LEFT JOIN Classes cl ON p.professor_id = cl.professor_id
LEFT JOIN Enrollment e ON cl.class_id = e.class_id
GROUP BY p.professor_name; 

--  Find Students Who Are Enrolled in More Than One Course
SELECT s.student_name, COUNT(e.class_id) AS course_count
FROM Students s
JOIN Enrollment e ON s.student_id = e.student_id
GROUP BY s.student_name
HAVING course_count > 1; 

