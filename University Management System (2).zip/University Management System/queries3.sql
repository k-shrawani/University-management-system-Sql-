use university;
select*from students;
select*from professors;
select*from departments;
select*from courses;
select*from classes;
select * from enrollment;

-- Get Average Grades for Each Course
SELECT c.course_name, AVG(CAST(e.grade AS FLOAT)) AS average_grade
FROM Courses c
JOIN Classes cl ON c.course_id = cl.course_id
JOIN Enrollment e ON cl.class_id = e.class_id
GROUP BY c.course_name;

--  Find All Courses Not Enrolled by Any Students
SELECT c.course_name 
FROM Courses c
LEFT JOIN Classes cl ON c.course_id = cl.course_id
LEFT JOIN Enrollment e ON cl.class_id = e.class_id
WHERE e.student_id IS NULL;

-- Count the Number of Courses in Each Department
SELECT d.department_name, COUNT(c.course_id) AS course_count
FROM Departments d
LEFT JOIN Courses c ON d.department_id = c.department_id
GROUP BY d.department_name;

--  Get the List of All Students and Their Enrollment Dates
SELECT student_name, enrollment_date 
FROM Students;

-- Find Professors Teaching More Than One Course
SELECT p.professor_name, COUNT(cl.class_id) AS course_count
FROM Professors p
JOIN Classes cl ON p.professor_id = cl.professor_id
GROUP BY p.professor_name
HAVING course_count > 1;

-- Get All Courses and Their Associated Professors
SELECT c.course_name, p.professor_name 
FROM Courses c
JOIN Classes cl ON c.course_id = cl.course_id
JOIN Professors p ON cl.professor_id = p.professor_id;

-- Find the Highest Grade in Each Course
 SELECT c.course_name, MAX(e.grade) AS highest_grade
FROM Courses c
JOIN Classes cl ON c.course_id = cl.course_id
JOIN Enrollment e ON cl.class_id = e.class_id
GROUP BY c.course_name;

-- Get All Students with a Specific Grade (e.g., 'A')
SELECT s.student_name 
FROM Students s
JOIN Enrollment e ON s.student_id = e.student_id
WHERE e.grade = 'A';

-- Get Total Number of Students Enrolled in the University
SELECT COUNT(*) AS total_students 
FROM Students;

-- Find All Departments with No Courses
SELECT d.department_name 
FROM Departments d
LEFT JOIN Courses c ON d.department_id = c.department_id
WHERE c.course_id IS NULL;

-- Get the Enrollment Dates of All Students Sorted by Date
SELECT student_name, enrollment_date 
FROM Students
ORDER BY enrollment_date;