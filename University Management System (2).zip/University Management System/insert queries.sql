-- Inserting sample data to test the schema 
-- Deparments

INSERT INTO Departments (department_name)
VALUES ('Computer science'),('physics'),('mathematics'),('biotechnology'),
('chemistry'),('electrical engineering'),('mechanical engineering'),('civil engineering'),
('economics'),('history'),('arts'); 
-- Inserting sample data to test the schema 
-- professors

INSERT INTO Professors (professor_name,email,department_id)
VALUES ('Dr.Arun Kumar','arun.kumar@university.in',1),
('Dr.Priya Sharma','priya.sharma@university.in',2),
('Dr.Rajesh Sharma','rajesh.sharma@university.in',3),
('Dr.Suman Rao','suman.rao@university.in',4),
('BE.Vikram Iyer','vikram.iyaer@university.in',5),
('Dr.Anjali Deshmukh','anjali.deshmukh@university.in',6),
('Dr.Rohit Menon','ronit.menon@university.in',7),
('Dr.Nisha Joshi','nisha.joshi@university.in',8),
('Dr.Siddharth.Kulkarni','siddharth.kulkarni@university.in',9),
('Dr.Narayan Shinde','nirayan.shinde@university.in',10);
-- Inserting sample data to test the schema students
-- students

INSERT INTO Students (student_name,email,enrollment_date)
VALUES ('Rahul Singh', 'rahul.singh@student.university.in', '2023-09-01'),
('Anjali Gupta', 'anjali.gupta@student.university.in', '2023-09-02'),
('Kiran Mehta', 'kiran.mehta@student.university.in', '2023-09-02'),
('Rohit Sharma', 'rohit.sharma@student.university.in', '2023-09-03'),
('Sneha Patil', 'sneha.patil@student.university.in', '2023-09-03'),
('Amit Yadav', 'amit.yadav@student.university.in', '2023-09-04'),
('Pooja Desai', 'pooja.desai@student.university.in', '2023-09-04'),
('Suresh Babu', 'suresh.babu@student.university.in', '2023-09-05'),
('Rekha Rao', 'rekha.rao@student.university.in', '2023-09-05'),
('Gaurav Patil', 'gaurav.patil@student.university.in', '2023-09-06'),
('Bharti Sharma', 'bharti.sharma@student.university.in', '2023-09-07'),
('Niya Mishra', 'niya.mishra@student.university.in', '2023-09-07'),
('Nilam Pawar', 'nilam.pawar@student.university.in', '2023-09-10'),
('Rahul Joshi', 'rahul.joshi@student.university.in', '2023-09-11'),
('Rahul Singh', '@student.university.in', '2023-09-15'),
('Priyanka Deshmukh', 'priyanka.deshmukh@student.university.in', '2023-09-15'),
('Nikhil Deshmukh', 'nikhil.deshmukh@student.university.in', '2023-09-15'),
('Kaveri Mathpati ', 'kaveri.mathpati@student.university.in', '2023-09-15'),
('Aarya Pendse', 'aarya.pendase@student.university.in', '2023-09-15'),
('Trupti Desai', 'trupti.desai@student.university.in', '2023-09-16');
-- Inserting sample data to test the schema Courses 
-- courses

INSERT INTO Courses (course_name, department_id)
VALUES ('Data Structures', 1),
('Quantum Mechanics', 2),
('Linear Algebra', 3),
('Genetics', 4),
('Organic Chemistry', 5),
('Electrical Circuits', 6),
('Thermodynamics', 7),
('Structural Engineering', 8),
('Microeconomics', 9),
('Modern Indian History', 10),
('Algorithms', 1),
('Optics', 2),
('Real Analysis', 3),
('Biotechnology Lab', 4),
('Inorganic Chemistry', 5),
('Digital Signal Processing', 6),
('Fluid Mechanics', 7),
('Transportation Engineering', 8),
('Macroeconomics', 9),
('Ancient Indian History', 10); 
ALTER TABLE Courses
ADD department_id INT;

-- Inserting sample data to test the schema Classes
-- Classes
INSERT INTO  Classes (course_id,professor_id,semester)
VALUES
(1, 1, 'Fall 2023'),
(2, 2, 'Fall 2023'),
(3, 3, 'Fall 2023'),
(4, 4, 'Fall 2023'),
(5, 5, 'Fall 2023'),
(6, 6, 'Fall 2023'),
(7, 7, 'Fall 2023'),
(8, 8, 'Fall 2023'),
(9, 9, 'Fall 2023'),
(10, 10, 'Fall 2023'),
(11, 1, 'Fall 2023'),
(12, 2, 'Fall 2023'),
(13, 3, 'Fall 2023'),
(14, 4, 'Fall 2023'),
(15, 5, 'Fall 2023'),
(16, 6, 'Fall 2023'),
(17, 7, 'Fall 2023'),
(18, 8, 'Fall 2023'),
(19, 9, 'Fall 2023'),
(20, 10, 'Fall 2023');
-- Inserting sample data to test the schema
-- Enrollment

INSERT INTO Enrollment (student_id,class_id,enrollment_date,grade)
VALUES (1, 1, '2023-09-02', 'A'),
(2, 2, '2023-09-03', 'B+'),
(3, 3, '2023-09-03', 'A'),
(4, 4, '2023-09-04', 'B'),
(5, 5, '2023-09-05', 'A'),
(6, 6, '2023-09-05', 'C+'),
(7, 7, '2023-09-06', 'B+'),
(8, 8, '2023-09-07', 'A'),
(9, 9, '2023-09-08', 'B'),
(10, 10, '2023-09-08', 'A'),
(1, 11, '2023-09-09', 'A'),
(2, 12, '2023-09-10', 'B+'),
(3, 13, '2023-09-10', 'A'),
(4, 14, '2023-09-11', 'B'),
(5, 15, '2023-09-12', 'A'),
(6, 16, '2023-09-13', 'C+'),
(7, 17, '2023-09-14', 'B+'),
(8, 18, '2023-09-15', 'A'),
(9, 19, '2023-09-15', 'B'),
(10, 20, '2023-09-16', 'A');
