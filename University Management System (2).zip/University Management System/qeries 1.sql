use university;
select*from students;
select*from professors;
select*from departments;
select*from courses;
select*from classes;
select * from enrollment;

-- Get students enrolled in a specific courses
SELECT s.student_name, e.grade
FROM Students s
JOIN Enrollment e ON s.student_id = e.student_id
JOIN Classes c ON e.class_id = c.class_id
JOIN Courses co ON c.course_id = co.course_id
WHERE co.course_name = 'Data Structures';

-- Get all courses offered by a specific department ('mathematics')
SELECT c.course_name
FROM Courses c
JOIN Departments d ON c.department_id = d.department_id
WHERE d.department_name = 'mathematics';

-- List all professors in the 'Physics' department
SELECT p.professor_name
FROM Professors p
JOIN Departments d ON p.department_id = d.department_id
WHERE d.department_name = 'Physics';

-- Get class details for a specific professor ('Dr. Anjali Deshmukh')
SELECT cl.class_id, c.course_name, cl.semester
FROM Classes cl
JOIN Professors p ON cl.professor_id = p.professor_id
JOIN Courses c ON cl.course_id = c.course_id
WHERE p.professor_name = 'Dr. Anjali Deshmukh';

--  Get all students who received an 'A' grade
SELECT s.student_name
FROM Students s
JOIN Enrollment e ON s.student_id = e.student_id
WHERE e.grade = 'A';




